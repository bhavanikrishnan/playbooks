M2_HOME={{ maven_dir }}
export M2_HOME

export M2=$M2_HOME/bin
export PATH=$M2:$PATH